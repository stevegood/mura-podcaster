jQuery(function($){
	
	alert("Ready!");
	
});